
import UIKit


import Foundation

let accounts = ["Cash", "Credit Card", "Bank Account"]
let categoriesExpenses = ["Taxes", "Grocery", "Entertainment", "Gym", "Health" ]
let categoriesIncome = ["Wages", "Dividents"]

//Cash
    var TaxesOne: Int = 500
    var GroceryOne: Int = 700
    var EntertainmentOne: Int = 200
    var GymOne: Int = 300
    var HealthOne: Int = 800
    var SummaryOne = TaxesOne + GroceryOne + EntertainmentOne + GymOne + HealthOne
print ("Your Cash ballance is \(SummaryOne)")

//Credit Card
    var TaxesTwo: Int = 500
    var GroceryTwo: Int = 700
    var EntertainmentTwo: Int = 200
    var GymTwo: Int = 300
    var HealthTwo: Int = 800
    var SummaryTwo = TaxesTwo + GroceryTwo + EntertainmentTwo + GymTwo + HealthTwo
print ("Your Cash ballance is \(SummaryTwo)")

//Bank Account
    var TaxesThree: Int = 500
    var GroceryThree: Int = 700
    var EntertainmentThree: Int = 200
    var GymThree: Int = 300
    var HealthThree: Int = 800
    var SummaryThree = TaxesThree + GroceryThree + EntertainmentThree + GymThree + HealthThree
print ("Your Cash ballance is \(SummaryThree)")




let name = "Name"
var currency: [String : String] = ["CurrencyOne"   : "UA",
                                   "CurrencyTwo"   : "USD",
                                   "CurrencyThree" : "EURO"]




 print("Please write your name:")

if let accountName = readLine() {
   print("output :",accountName)
} else {
   print("Nothing")
}



let groceryStore = 750


if groсeryStore == 500 {
    print ("Чек за продукты вышел 500")
} else if groceryStore == 250 {
    print ("Вы купили продуктов на 250")
} else if groceryStore == 750 {
    print ("Продуктовый магазин 750")
}


let category = ["Home", "Health & Fitness", "Salary", "Food", "Taxes"]
for i in category {
    print(i)
}


let transaction = 35

switch transaction {
case 10:
    print ("Create transaction for Home")
case 20:
    print ("Create transaction for HealthandFitness")
case 35:
    print ("Create transaction for Salary")
case 50:
    print ("Create transaction for Food")
case 55:
    print ("Create transaction for Taxes")
}


